export class SubscriptionModel {
    hhcTier = 'HHCStandard';
    hhcAdditionalContacts = 'Unknown';
    hhcDevices = 0;

    contactBlocks = 0;
    aemTier = 'Unknown';
    callList = false;

    quantity = 1;
    advancedSupport = 'None';

    license = '';

    constructor() {
    }
}



