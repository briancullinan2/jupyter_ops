import { Component } from '@angular/core';


@Component({
    selector: 'bc-funnel-footer',
    templateUrl: './footer.html',
    styleUrls: ['./footer.scss']
})
export class FunnelFooterComponent {

    constructor() {

    }

}
