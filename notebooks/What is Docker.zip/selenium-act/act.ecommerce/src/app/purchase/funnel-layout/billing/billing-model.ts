export class BillingModel {
    name = '';
    number = '';
    expiration = '';
    year = '';
    cvv = '';
    address = '';
    country = '';
    state = '';
    city = '';
    postal = '';

    constructor() {}
}


