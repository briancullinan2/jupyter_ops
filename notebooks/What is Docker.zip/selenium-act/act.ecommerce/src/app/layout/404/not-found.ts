﻿import { Component } from '@angular/core';


@Component({
  selector: 'bc-not-found-page',
  templateUrl: './not-found.html',
  styleUrls: ['./not-found.scss']
})
export class NotFoundComponent { }
