﻿import {Component} from '@angular/core';


@Component({
    selector: 'bc-support-nav',
    templateUrl: './support.html'
})
export class SupportMenuComponent {

    constructor() {
    }
}

