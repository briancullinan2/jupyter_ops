import { Component } from '@angular/core';


@Component({
    selector: 'bc-menu',
    templateUrl: './menu.html',
    styleUrls: ['./menu.scss']
})
export class MenuComponent {
}
