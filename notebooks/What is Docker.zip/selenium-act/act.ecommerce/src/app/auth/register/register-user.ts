export class RegistrationUser {
    [key: string]: string;

    firstName = '';
    lastName = '';
    email = '';
    password = '';
    companyName = '';
    phoneNumber = '';

    constructor() {
    }
}


