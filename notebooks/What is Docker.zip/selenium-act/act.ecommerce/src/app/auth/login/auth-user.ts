export class AuthUser {
    constructor(public name: string,
                public password: string) {
    }
}

