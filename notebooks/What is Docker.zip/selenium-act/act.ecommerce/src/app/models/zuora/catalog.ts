﻿import { Product } from './product';


export class Catalog {

    products: Product[];

    constructor() {
        this.products = [];
    }
}
