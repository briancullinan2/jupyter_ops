﻿export class SubscriptionPreview {
    amount: string;
    amountWithoutTax: string;
    taxAmount: string;
    invoiceItems: { [key: string]: any }[];

    constructor() {
    }
}
