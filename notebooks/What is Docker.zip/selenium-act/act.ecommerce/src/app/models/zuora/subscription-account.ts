﻿import { Subscription } from './subscription';

export class SubscriptionAccount {

   subscriptions: Subscription[];

    constructor() {
        this.subscriptions = [];
    }
}
