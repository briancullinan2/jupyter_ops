

export class RatePlanCharge {
    id: string;
    name: string;

    constructor() {
    }
}
