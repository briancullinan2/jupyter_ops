
import {Injectable} from '@angular/core';
@Injectable()
export class TranslateServiceStub {
    constructor() {
    }
}

@Injectable()
export class TranslateStoreStub {
    constructor() {
    }
}

@Injectable()
export class TranslateParserStub {
    constructor() {
    }
}

@Injectable()
export class MissingTranslationHandlerStub {
    constructor() {
    }
}


@Injectable()
export class TokenStub {
    constructor() {
    }
}
