const commonConfig = require('environment');

export const environment = Object.apply(commonConfig, {
  production: true
});
