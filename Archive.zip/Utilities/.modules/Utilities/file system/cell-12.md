list project files?

List files in a project excluding some excessive searches locations?

