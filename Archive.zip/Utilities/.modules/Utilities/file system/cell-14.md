List all projects by names?

