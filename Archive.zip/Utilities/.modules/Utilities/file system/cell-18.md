Find too long of functions using regexp?
(?=\{((?:[^{}]++|\{(?1)\})++)\})

TODO: turn this in to a bs-lint test

TODO: use a recusive decent parser to apply to all languages, test finding long python functions which are white-space delimited
