test project files list
