var importer = require('../Core');
var path = require('path');
var d3CloudToSVG = importer.import('d3.ipynb[create word-cloud]');
    
function projectWordCloud(project) {
    var relativePaths = importer.import('relative paths and includes', {project});
    var words = [];

    function wordCount(r) {
        var words = r['packages'].map(p => p.split('.ts/')[1])
            .concat(r['packages'].map(p => path.basename(p.split('.ts/')[0])))
            .concat(r['relatives'].map(r => path.basename(r)))
            .concat(r['relatives'].map(r => path.basename(r.split('.ts/')[0])));
        var wordCount = {};
        words.forEach(w => {
            if (typeof wordCount[w] === 'undefined') {
                wordCount[w] = 15;
            } else {
                wordCount[w]++;
            }
        });
        return Object.keys(wordCount).map((d) => ({text: d, size: wordCount[d]}));
    };

    return relativePaths(project)
        .then(words => d3CloudToSVG(wordCount(words)));
};
module.exports = projectWordCloud;

