Fix project paths?

