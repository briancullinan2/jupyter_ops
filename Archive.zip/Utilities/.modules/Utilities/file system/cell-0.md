How to use memory-fs and rewire to audit cli events?

