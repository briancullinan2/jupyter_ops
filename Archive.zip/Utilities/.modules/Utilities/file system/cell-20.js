var PROFILE_PATH = process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE;
var project = PROFILE_PATH + '/Documents/asm';

$$.async();
findLongFunctions(project)
    .then(e => $$.sendResult(e.map(m => m.path)))
    .catch(e => $$.sendError(e))
