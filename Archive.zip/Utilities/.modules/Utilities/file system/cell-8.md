Find similar filename in project?

