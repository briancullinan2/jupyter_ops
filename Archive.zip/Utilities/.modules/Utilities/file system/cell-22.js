var fs = require('fs');
var path = require('path');

function mkdirpSync(p) {
    if(!fs.existsSync(p)) {
        try {
            fs.mkdirSync(p);
        } catch (e) {
            if(e.code === 'ENOENT') {
                mkdirpSync(path.dirname(p));
                fs.mkdirSync(p);
            }
        }
    }
}
module.exports = mkdirpSync;
