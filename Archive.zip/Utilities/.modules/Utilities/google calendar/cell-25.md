Parse bookmarks file?

