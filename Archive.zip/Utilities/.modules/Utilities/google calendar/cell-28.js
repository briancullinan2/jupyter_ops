var {JSDOM} = require('jsdom');
var fs = require('fs');
var importer = require('../Core');
var glob = require('glob');
var path = require('path');
var fs = require('fs');
var _ = require('lodash');

var offset = (new Date()).getTimezoneOffset() * 60 * 1000;
// TODO: search using glob but include same list of excludes, how to abstract?
var PROFILE_PATH = process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE;
var PROJECT_PATH = PROFILE_PATH + '/Downloads';

var {
    getOauthClient, ISODateString, updateEvent, correctCalendarId
} = importer.import([
    'import google calendar api',
    'lookup calendar name',
    'convert date iso',
    'update create merge event'
]);
var options = {
    calendarId: 'Bookmarks'
};

function syncChromeBookmarks() {
    var files = glob.sync('Takeout*/Chrome/Bookmarks.html', {cwd: PROJECT_PATH})
        .map(f => path.join(PROJECT_PATH, f));
    files.sort((a, b) => fs.statSync(a).ctime - fs.statSync(b).ctime);
    // parse bookmark html
    var dom = new JSDOM(fs.readFileSync(files.pop()).toString());
    var r = importer.import(['all elements xpath', 'parse bookmarks file'], {
        client: {
            execute: (func, ...args) => Promise.resolve({
                value: func.apply(dom.window.document, args)
            }),
            addCommand: () => {
            }
        },
        document: dom.window.document,
        XPathResult: {ORDERED_NODE_ITERATOR_TYPE: 5}
    });
    var parseBookmarks = r.parseBookmarks;
    return getOauthClient(options)
        .then(() => correctCalendarId(options))
        .then(() => parseBookmarks())
        // TODO: copy to chrome history
        .then(links => {
            const groups = Object.keys(links).sort((a, b) => parseInt(b) - parseInt(a));
            console.log(groups.slice(0, 10));
            console.log(new Date(parseInt(groups[0]) - offset * 1000));
            return groups.reduce((acc, t) => {
                const folders = _.groupBy(links[t], l => l.folder);
                return acc.concat(Object.keys(folders).map(f => ({
                    start: {
                        dateTime: ISODateString(new Date(parseInt(t) - offset))
                    },
                    end: {
                        dateTime: ISODateString(new Date(parseInt(t) + 60 * 30 * 1000 - offset))
                    },
                    summary: f,
                    description: JSON.stringify(folders[f], null, 4)
                })))
            }, [])
        })
        .then(results => {
            return importer.runAllPromises(results
                .map(event => resolve => updateEvent(event, options)
                    .then(r => resolve(r))
                    .catch(e => {
                        console.log(e);
                        resolve()
                    })))
        })
        .catch(e => console.log(e))
}
module.exports = syncChromeBookmarks;

