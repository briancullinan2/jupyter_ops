Show a d3 pie chart of time spent on projects?

