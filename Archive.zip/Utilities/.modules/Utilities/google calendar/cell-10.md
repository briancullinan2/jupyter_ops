
test calendar sum all hours worked on study sauce since september 2016

