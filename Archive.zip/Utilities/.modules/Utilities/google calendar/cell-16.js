var importer = require('../Core');
var {
    fuseSearch, interpretObject
} = importer.import('interpret all notebooks.ipynb');

var queries = 'scrape facebook events';

$$.async();
(r => typeof queries === 'string'
        ? fuseSearch(queries)
        : Promise.all(queries.map(fuseSearch)))
    //.then(r => typeof queries == 'string'
    //      ? interpretObject([r[0]])
    //      : interpretObject(r.map(r => r[0])))
    .then(r => $$.sendResult(r))
    .catch(e => $$.sendError(e));
