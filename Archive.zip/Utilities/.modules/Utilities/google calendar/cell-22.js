var chrono = require('chrono-node');
var importer = require('../Core');
var {
    ISODateString,
    listEvents 
} = importer.import([
    'convert date iso',
    'list events'
]);

var eventCache = {};
function getDaysEvents(startDate, options) {
    startDate = chrono.parseDate(startDate + '');
    var day = new Date(startDate);
    day.setHours(0, 0, 0);
    var dayEnd = new Date(day);
    dayEnd.setDate(dayEnd.getDate() + 1);
    var todaysEvents;
    if(typeof eventCache[options.calendarId] === 'undefined') {
        eventCache[options.calendarId] = {};
    }
    if(typeof eventCache[options.calendarId][day.getTime()] !== 'undefined') {
        todaysEvents = Promise.resolve(eventCache[options.calendarId][day.getTime()])
    } else {
        console.log({
            timeMin: ISODateString(new Date(day.getTime())),
            timeMax: ISODateString(new Date(dayEnd.getTime()))
        });
        todaysEvents = listEvents({
            auth: options.auth,
            calendarId: options.calendarId,
            timeMin: ISODateString(new Date(day.getTime())),
            timeMax: ISODateString(new Date(dayEnd.getTime()))
        })
        .catch(e => console.log(e))
    }
    return todaysEvents
        .then(m => {
            eventCache[options.calendarId][day.getTime()] = m;
            return m.filter(e => e.event.deleted !== true)
        })
        .catch(e => console.log(e))
}
module.exports = getDaysEvents;
