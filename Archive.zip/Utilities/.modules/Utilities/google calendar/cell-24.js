var google = require('googleapis');
var calendar = google.calendar('v3');
var importer = require('../Core');
var chrono = require('chrono-node');

function googlePromise(func) {
    return new Promise((resolve, reject) => func((err, response) => {
        if (err) reject(err);
        try {
        } catch (e) {
            reject(e);
        }
        setTimeout(() => resolve(response), 100);
    })).catch(e => console.log(e));
};

var {
    ISODateString, correctCalendarId
} = importer.import([
    'convert date iso',
    'lookup calendar name',
])

function updateEvent(event, options) {
    const getDaysEvents = importer.import('days events');
    return correctCalendarId(options)
        .then(() => getDaysEvents(event.start.dateTime, options))
        .then(m => {
            const actionsArray = [];
            const matches = m.filter(match => !match.event.deleted && match.event.summary === event.summary
                                    && Math.abs(Math.round(new Date(match.event.start.dateTime).getTime() / 1000 / 60)
                                        - Math.round(new Date(event.start.dateTime).getTime() / 1000 / 60)) < 29);
            console.log('Matching ' + matches.length);
        
            if (matches.length > 0) {
                var descriptions = [];
                try {
                    descriptions = descriptions.concat(JSON.parse(event.description) || []);
                } catch (e) {
                }
                descriptions = descriptions.concat(
                    ...matches.map(match => {
                        try {
                            return JSON.parse(match.event.description)
                        } catch (e) {
                            return [];
                        }
                    }));
                // TODO: make sure there are no duplicates
                // TODO: move this in to some parsing utility?
                // TODO: deep compare instead of just comparing "url" property?
                const urls = descriptions.map(d => (d || {}).url);
                const unique = descriptions.filter((d, i) => urls.indexOf((d || {}).url) === i);

                // patch the first match
                var newDescription = JSON.stringify(unique, null, 4);
                if(matches[0].event.description !== newDescription) {
                    actionsArray.push(googlePromise(
                        calendar.events.patch.bind(calendar.events, {
                            eventId: matches[0].event.id,
                            calendarId: options.calendarId,
                            auth: options.auth,
                            resource: {
                                description: newDescription,
                                colorId: event.colorId
                            }
                        })));
                }

                // TODO: delete the rest
                for (const match of matches.slice(1)) {
                    match.event.deleted = true;
                    actionsArray.push(googlePromise(
                        calendar.events.delete.bind(calendar.events, {
                            eventId: match.event.id,
                            calendarId: options.calendarId,
                            auth: options.auth
                        })));
                }
            } else {
                console.log('adding event ' + event.summary)
                actionsArray.push(googlePromise(
                    calendar.events.insert.bind(calendar.events, {
                        calendarId: options.calendarId,
                        auth: options.auth,
                        resource: event
                    })));
            }
            return importer.runAllPromises(actionsArray);
        })
        .catch(e => console.log(e))
};
module.exports = updateEvent;
