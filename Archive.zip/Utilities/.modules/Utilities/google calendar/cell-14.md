Lookup calendar id by name or id?

