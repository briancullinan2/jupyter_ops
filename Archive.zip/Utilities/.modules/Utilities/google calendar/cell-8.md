test calendar api graph Iga's cycle for as long as there are valid dates

