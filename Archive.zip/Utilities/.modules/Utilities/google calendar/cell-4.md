Run todays calendar events?

