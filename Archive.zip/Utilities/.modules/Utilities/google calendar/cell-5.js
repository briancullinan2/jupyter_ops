var google = require('googleapis');
var importer = require('../Core');
var {
    getOauthClient,
    listEvents,
    storeResult
} = importer.import([
    'list events',
    'import google calendar api',
    'store rpc result'
]);

var options = {
    calendarId: 'commands'
};

// test Google calendar API?
function runTodaysEvents() {
    return (typeof options.auth === 'undefined'
           ? getOauthClient(options)
           : Promise.resolve([]))
        .then(() => listEvents({
            auth: options.auth,
            calendarId: options.calendarId,
            timeMin: '12 AM today',
            timeMax: 'next hour today'
        }))
        // filter processed
        .then(events => {
            // TODO: create object with property "already" and filter out like other RPC methods?
            const commandEvent = events
                .filter(e => {
                    const matches = events
                        .filter(m => 'Result: ' + e.event.summary === m.event.summary
                            && e.event.start.dateTime === m.event.start.dateTime);
                    return e.event.summary.indexOf('Result:') === -1 && matches.length === 0
                })[0]
            if (typeof commandEvent === 'undefined') throw new Error('No events!');
            var parameters;
            try { 
                parameters = JSON.parse(commandEvent.event.description)
                    || commandEvent.event.description.trim().split(/\n/ig);
            } catch ( e ) {
            }
            return {
                already: false, // filtered out above
                body: parameters,
                name: 'Today\'s events',
                command: commandEvent.event.summary.trim(),
                date: new Date(commandEvent.event.start.dateTime),
                id: commandEvent.event.summary.trim(),
                circles: ['Function', 'Selenium'],
                result: importer.interpret(commandEvent.event.summary.trim()),
                allowed: true // TODO: use RPC filter because it's safer?
            };
        })
        // use rpc
        .then(f => storeResult(f))
        .catch(e => console.log(e))
};
module.exports = runTodaysEvents;

// node -e "require('/Users/briancullinan/jupytangular2/Core').import('heartbeat')('run todays calendar events')"

// echo "require('/Users/briancullinan/jupytangular2/Core').import('scrape facebook events').then(runner => runner()).then(e=>{console.log(e); process.exit(e) }).catch(e=>{console.log(e); process.exit(e) });" | node

