var importer = require('../Core');

function chromeDtToDate(st_dt) {
   var microseconds = parseInt(st_dt, 10);
   var millis = microseconds / 1000;
   var past = new Date(1601, 0, 1).getTime();
   return new Date(past + millis);
}

function parseBookmarks() {
    return getAllXPath([
        '//dt[./h3]',
        {
            title: './h3/text()',
            links: [
                './dl/dt/a',
                {
                    url: './@href',
                    time: './@add_date',
                    title: './@text()'
                }
            ],
            children: ['./dl/dt/h3/text()']
        }
    ])
        .then(events => [].concat(...events.map(e => e.links.map(l => Object.assign(l, {folder: e.title})))))
        .then(events => {
            return events.map(e => Object.assign(e, {
                url: e.url + '',
                title: e.title + '',
                time_usec: parseInt(e.time + '')
            }))
                .reduce((links, event) => {
                    // group by nearest half-hour and max out at 10 links
                    var timeGroup = Math.round(chromeDtToDate(event.time_usec).getTime() / 1000 / 60 / 30) * 1000 * 60 * 30;
                    if (typeof links[timeGroup] == 'undefined') {
                        links[timeGroup] = [];
                    }
                    links[timeGroup].push(event)
                    return links;
                }, {})
        });
};
module.exports = parseBookmarks;
parseBookmarks;

