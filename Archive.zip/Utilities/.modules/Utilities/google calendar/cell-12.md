Correct calendar dates for timeMax and timeMin?
