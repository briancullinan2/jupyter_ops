How to display recurrence line graph?
