How to sum a list of events?

