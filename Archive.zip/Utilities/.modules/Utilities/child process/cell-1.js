var {exec} = require('child_process');
var path = require('path');
// read cmd template and execute each line?
var corePath = path.resolve(path.join(__dirname, '..', 'Core'));
var importer = require(corePath);
function bashToExec(code) {
    return code.split(/\s*(\n\s*)+/ig)
    .map(l => '{EXEC} ' + l)
    .join('\n').replace(/\\\s*\n\{EXEC\}\s*/ig, '\\\n ');
}

function execCmd(script, options) {
    // add some run commands to the bash script
    return importer.runAllPromises(
        bashToExec(script).split(/\s*\{EXEC\}\s*/ig)
            .filter(r => r.trim() !== '')
            .map(r => new Promise((resolve, reject) => {
                const ps = exec(r, Object.assign(options || {}, {maxBuffer: 1024 * 50000}),  (err, result) => {
                    if (err) {
                        return resolve(err.toString());
                    }
                    resolve(result.toString());
                });
                ps.stderr.on('data', d => console.error(d));
                ps.stdout.on('data', d => console.log(d));
            })));
};
module.exports = execCmd;

