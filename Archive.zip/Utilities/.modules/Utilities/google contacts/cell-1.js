var google = require('googleapis');
var people = google.people('v1');
var importer = require('../Core');
var getOauthClient = importer.import('import google calendar api');

var options = {
    scopes: [
        'https://www.googleapis.com/auth/contacts'
    ]
};

function findMatch(arr, contact) {
    return arr.filter(c => (
        typeof c.names !== 'undefined'
        && typeof contact.displayName !== 'undefined'
        && c.names.filter(n => n.displayName.match(new RegExp(contact.displayName, 'ig'))).length > 0)
        || (
        typeof c.emailAddresses !== 'undefined'
        && typeof contact.emailAddress !== 'undefined'
        && c.emailAddresses.filter(e => e.value.match(new RegExp(contact.emailAddress, 'ig'))).length > 0)
                      );
}

function googlePromise(func) {
    return new Promise((resolve, reject) => func((err, response) => {
        if (err) reject(err);
        try {
        } catch (e) {
            reject(e);
        }
        setTimeout(() => resolve(response), 100);
    })).catch(e => console.log(e));
};

var contactCache = [];
function listContacts(contact, done = false) {
    // return matching contacts or empty if there are no more pages
    return googlePromise(
        people.people.connections.list.bind(people.people.connections, {
            resourceName: 'people/me',
            personFields: 'emailAddresses,names,birthdays,phoneNumbers,memberships',
            auth: options.auth,
            pageToken: options.pageToken
        }))
        .then(r => {
            options.pageToken = r.nextPageToken;
            done = !options.pageToken;
            return r.connections;
        })
        .then(r => {
            for (var c of r) {
                contactCache.push(c);
            }
            if (done) {
                return findMatch(contactCache, contact);
            }
            return listContacts(contact, done);
        })
        .catch(e => console.log(e))
};

function getContacts(contact) {
    return getOauthClient(options)
        .then(() => {
            if (contactCache.length > 0) {
                return findMatch(contactCache, contact);
            }
            options.nextPageToken = null;
            contactCache = [];
            return listContacts(contact);
        })
        .catch(e => console.log(e))
};
module.exports = getContacts;
