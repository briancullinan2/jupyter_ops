var importer = require('../Core');
var getSettings = importer.import('google contact settings');

$$.async();
getSettings('megamindbrian@gmail.com')
    .then(r => $$.sendResult(r))
    .catch(e => $$.sendError(e))
