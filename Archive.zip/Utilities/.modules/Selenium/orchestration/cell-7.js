var importer = require('../Core');

var windowCounter = -1;
function repositionSession(s, reposition = true) {
    client.requestHandler.sessionID = s;
    return client
        .getUrl()
        .windowHandles()
        .then(h => {
            console.log(h);
            return importer.runAllPromises(h.value.map(hwnd => resolve => {
                windowCounter++
                return client
                    .window(hwnd)
                    .then(() => reposition ? resizeWindow(windowCounter) : [])
                    .getUrl()
                    .then(r => resolve(r))
                    .catch(e => console.log(e))
            }));
        });
}

function getAllSessionUrls(reposition = true) {
    var session = client.requestHandler.sessionID;
    return client
        .getSessions()
        .then(r => {
            console.log(r);
            return importer.runAllPromises(r.map(s => resolve => {
                return repositionSession(s, reposition)
                    .catch(e => console.log(e))
                    .then(r => resolve(r));
            }));
        })
        .then(r => {
            client.requestHandler.sessionID = session;
            return r;
        })
        .catch(e => console.log(e))
}

module.exports = getAllSessionUrls;
