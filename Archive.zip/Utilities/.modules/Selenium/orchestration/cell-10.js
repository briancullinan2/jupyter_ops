
function sendJoke(hwnd) {
    var joke;
    return client
        .then(() => getJoke())
        .then(r => joke = r)
        .window(hwnd)
        .then(() => sendFacebookMessage(joke[0]))
        .pause(20000)
        .then(() => sendFacebookMessage(joke[1]))
}
module.exports = sendJoke;
