var path = require('path');
var fs = require('fs');
var importer = require('../Core');
var {
    getSeleniumServer,
    runSeleniumCell
} = importer.import([
    'selenium docker',
    'set up selenium server',
    'selenium cell'
]);

var regexToArray = (ex, str, i = 0) => {
    var co = []; var m; while ((m = ex.exec(str)) && co.push(m[i])); return co;
};

var TOKEN_DIR = path.join(process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE, '.credentials');
var SESSIONS_PATH = path.join(TOKEN_DIR, 'sessions.json');

function cleanUpSessions() {
    var sessions;
    return getSeleniumServer()
        .then(r => regexToArray(/\/session\/(.+?)\//ig, r.join('\n'), 1))
        .then(r => sessions = r.filter((s, i, arr) => arr.indexOf(s) === i))
        .then(() => fs.writeFileSync(SESSIONS_PATH, '[]'))
        .catch(e => console.log(e))
        .then(() => runSeleniumCell(false))
        .catch(e => console.log(e))
        .then(() => console.log('done'))
}
module.exports = cleanUpSessions;
