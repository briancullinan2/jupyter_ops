Monitor many chats at once and continuously
