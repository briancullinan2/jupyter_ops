get all session and window urls?

