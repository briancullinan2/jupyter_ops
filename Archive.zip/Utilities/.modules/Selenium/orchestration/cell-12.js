function sendFacebookThanks(friend, hwnd) {
    return client
        .window(hwnd)
        .clickSpa(friend)
        .then(() => readFacebookThread(friend))
        .then(r => {
            const thanks = r.messages.filter(m => m.message.indexOf('dream') > -1);
            console.log(thanks);
            return thanks.length === 0
              ? sendFacebookMessage('Are you living the dream?')
              : []
        })
        .catch(e => console.log(e))
}
module.exports = sendFacebookThanks;
