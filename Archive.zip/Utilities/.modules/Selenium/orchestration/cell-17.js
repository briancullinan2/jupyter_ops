$$.async()
cleanUpSessions()
    .then(r => $$.sendResult(r))
    .catch(e => $$.sendError(e))