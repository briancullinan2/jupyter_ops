var importer = require('../Core');

function fillForm(obj) {
    const fields = Object.keys(obj);
    return importer.runAllPromises(fields.map(f => resolve => {
        return selectDropdown(f, obj[f])
            .catch(e => console.log(e))
            .then(r => resolve(r))
    }))
}
module.exports = fillForm;
