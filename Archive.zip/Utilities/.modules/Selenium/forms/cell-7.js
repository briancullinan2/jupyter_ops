var url = require('url')

var SIGN_IN = '//a[contains(.,"Sign in")]|//a[contains(.,"Log in")]|//a[contains(.,"Login")]|//a[contains(.,"Log In")]|//a[contains(.,"Sign In")]';

var MATCH_USERNAME = '//input[contains(@name, "Email")]|//input[contains(@name, "email")]|//input[contains(@name, "user")]';

var MATCH_PASSWORD = '//input[contains(@name, "pass")]|//input[contains(@name, "Pass")]|//input[contains(@autocomplete, "pass")]';

var MATCH_SUBMIT = '//*[@type = "submit"]'
    // google plus
    + '|//*[@role = "button"][contains(., "Next")]'
    // linkedin
    + '|//*[@type = "submit"][contains(., "Sign in")]';

function fillAll(obj) {
    const promises = [];
    for(const k of Object.keys(obj)) {
        promises.push((k => resolve => client
            .isExisting(k)
            .then(is => is && obj[k] !== false
                  ? client.click(k).keys(obj[k])
                  : (client
                     ? client.click(k)
                     : []))
            .then(() => resolve())
            .catch(e => resolve(e))
                      )(k));
    }
    
    return importer.runAllPromises(promises)
}

function multiLogin(baseUrl) {
    console.log(baseUrl);
    const parts = url.parse(baseUrl);
    const login = getCredentials(parts.hostname);
    const usernameField = Object.keys(login).filter(k => k.match(/user|mail|name/ig))[0];
    const passwordField = Object.keys(login).filter(k => k.match(/pass/ig))[0];
    return client
        .url(baseUrl)
        .isExisting(SIGN_IN)
        .then(is => is ? client.click(SIGN_IN) : [])
        // TODO: check for form elements or URL to see if it needs logging in again like Google an Facebook service do
        .then(() => {
            const obj = {};
            obj[MATCH_USERNAME] = login[usernameField];
            obj[MATCH_PASSWORD] = login[passwordField];
            obj[MATCH_SUBMIT] = false
            return fillAll(obj).then(() => fillAll(obj)).then(() => fillAll(obj))
        })
        .catch(e => console.log(e))
        .getUrl();
}
module.exports = multiLogin
