map object to form?

