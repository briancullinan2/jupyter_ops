function selectDropdown(label, value) {
    return client
        .click('//*[contains(., "' + label + '")][not(*)]/parent::*/*[contains(@role, "listbox")]' +
               '|//*[contains(@aria-label, "' + label + '")]//*[contains(@role, "listbox")]' + 
               '|//*[contains(@aria-label, "' + label + '")]//*[contains(@class, "button-dropdown")]') // [contains(@aria-selected, "true")]
        .pause(1000)
        .click('//*[contains(., "' + label + '")][not(*)]/parent::*//*[contains(@role,"option")][contains(.,"' + value + '")]' +
               // handle google angular drop down lists or google calendar drop down
               // TODO: break up this line in to two
               '|//*[contains(@aria-label, "' + label + '")]//*[contains(@class,"menuitem") or contains(@role, "gridcell")][not(contains(@class,"other-month"))][contains(.,"' + value + '")]')
        .pause(1000)
}
module.exports = selectDropdown;
