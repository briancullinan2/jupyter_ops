var fs = require('fs');
var path = require('path');
var importer = require('../Core');
var multiCrawl = importer.import('multi crawl');

var PROFILE_PATH = process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE;
var PASSWORDS_FILE = path.join(PROFILE_PATH, '.credentials', 'passwords.json');

function testLogins() {
    var sites = JSON.parse(fs.readFileSync(PASSWORDS_FILE)).map(s => s.host);
    sites = [
        'twitter.com',
        'linkedin.com',
        /*
        'angel.co',
        'linkedin.com',
        'facebook.com',
        'github.com',
        'plus.google.com'
        */
    ];

    console.log(sites);
    return multiCrawl(sites.map(s => 'https://' + s), 'log in multiple sites');    
}
module.exports = testLogins;

if(typeof $$ !== 'undefined') {
    $$.async();
    testLogins()
        .then(r => $$.sendResult(r))
        .catch(e => $$.sendError(e))
}

