click spa link?
