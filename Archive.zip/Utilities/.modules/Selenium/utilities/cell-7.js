function clickSpa(profile) {
    return client
        .getUrl()
        .then(url => url.indexOf(profile) > -1
              ? []
              : client
             .execute(url => {
                var a = document.createElement('a');
                a.setAttribute('href', url);
                a.setAttribute('class', 'spa');
                a.onclick = () => setTimeout(() => document.body.removeChild(a), 500)
                a.href = url;
                a.style.position = 'absolute';
                a.style.zIndex = 4294967295;
                a.style.top = 0;
                a.style.left = 0;
                a.style.bottom = 0;
                a.style.right = 0;
                document.body.appendChild(a);
            }, profile)
        .click('a.spa[href*="' + profile + '"]')
        .pause(1000))
        .catch(e => console.log(e))
};
if (typeof client.clickSpa == 'undefined') {
    client.addCommand('clickSpa', clickSpa);
}
module.exports = clickSpa;
