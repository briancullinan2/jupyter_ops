Get all elements until?

