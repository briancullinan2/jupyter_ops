var importer = require('../Core');
var {
    getAllXPath, scrollClient
} = importer.import([
    'all elements xpath',
    'scroll specific element'
], {client})

function getAllUntil(scrollableSelector,
                     dataSelector,
                     set = [],
                     compare = (a, b) => a === b,
                     cb = (i) => i < 3,
                     up = false,
                     i = 0) {
    return getAllXPath(dataSelector)
        .then(r => {
            var newPosts = ((typeof r === 'string' ? [r] : r) || [])
                .filter(e => set
                    .filter(m => compare(e, m)).length === 0);
            set = newPosts.concat(set);
            return newPosts.length > 0
                ? scrollClient(scrollableSelector, up)
                    .pause(4000)
                    .then(() => cb(i)
                        ? getAllUntil(scrollableSelector, dataSelector, set, compare, cb, up, i + 1)
                        : set)
                : Promise.resolve(set);
        })
        .catch(e => console.log(e))
};
if (typeof client.getAllUntil == 'undefined') {
    client.addCommand('getAllUntil', getAllUntil);
}
module.exports = getAllUntil;


