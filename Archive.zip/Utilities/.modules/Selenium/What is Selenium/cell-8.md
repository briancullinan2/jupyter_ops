## 3

How to run a selenium cell on the Docker machine?

