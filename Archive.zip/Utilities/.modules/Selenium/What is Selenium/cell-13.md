
TODO:

Auto fill fields in a live browser using the 

Transfer login state to current browser?

