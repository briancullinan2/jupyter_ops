var importer = require('../Core');
var createWebdriverClient = importer.import('webdriver client');

function runSeleniumCell(search, newWindow = true) {
    var client = createWebdriverClient();
    var ctx = {client};
    var {
        getCredentials,
        getAllXPath,
        getAllUntil,
        resizeWindow,
        onlyOneWindow,
        getAllSessionUrls,
        clickSpa,
    } = importer.import([
        'decrypt password',
        'all elements xpath',
        'get all elements until',
        'resize selenium window',
        'only one window',
        'get all session urls',
        'click spa link',
    ], ctx);
    var formUtilities = importer.import('form utilities', ctx);
    return client
        .getSessions()
        .then(() => (newWindow
                     ? client
                     .then(() => onlyOneWindow())
                     .then(() => getAllSessionUrls())
                     : []))
        .catch(e => console.log(e))
        .then(() => {
            if(!search) {
                return ctx;
            }
            return importer.import(search, Object.assign(ctx, {
                client: client,
                browser: client,
                getCredentials,
                getAllXPath,
                getAllUntil,
                resizeWindow,
                clickSpa,
            }, formUtilities))
        })
};
module.exports = runSeleniumCell;
