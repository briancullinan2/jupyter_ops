var importer = require('../Core');
var fs = require('fs');

// add some run commands to the bash script
function bashToRun(code) {
    return code.split('\n').filter(n => n.trim().length > 0).map(l => 'RUN ' + l.trim())
    .join('\n').replace(/\\\s*\nRUN\s*/ig, '\\\n ');
}

// create a selenium Dockerfile with a vnc connection
function seleniumDocker(outputFile) {
    const r = importer.interpret([
        'run selenium inside docker',
        // add some extra services
        'linux dev tools',
        'vnc html',
        'vnc docker'
    ]);
    // save the Dockerfile
    fs.writeFileSync(outputFile, [
        r[0].code,
        // convert some results to Docker RUN commands instead of bash
        bashToRun(r[1].code),
        bashToRun(r[2].code),
        r[3].code
    ].join('\n'));
    return r;
};
module.exports = seleniumDocker;
