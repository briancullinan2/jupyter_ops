var importer = require('../Core');
var {getSeleniumServer} = importer.import([
    'What is Selenium.ipynb[what is selenium]',
    'set up selenium server'
]);

$$.async();
getSeleniumServer()
    .then(r => $$.sendResult(r))
    .catch(e => $$.sendError(e));

