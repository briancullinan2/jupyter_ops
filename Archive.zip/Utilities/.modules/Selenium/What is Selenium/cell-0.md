# What is Selenium?

## 1

What environment do we use?

selenium docker?

See [What is Docker?](What%20is%20Docker.ipynb)

