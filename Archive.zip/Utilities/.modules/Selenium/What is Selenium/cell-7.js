$$.mime({'text/html': vncIframe()});
