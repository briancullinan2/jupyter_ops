var importer = require('../Core');
var sync = require('wdio-sync');

var client;
function createWebdriverClient(host, port) {    
    var webdriverServer = {
        services: ['selenium-standalone', 'chromedriver'],
        sync: false,
        debug: false,
        host: host || 'localhost',
        port: port || 4444,
        logLevel: 'command',
        baseUrl: 'https://webdriver.io',
        pageLoadStrategy: 'eager',
        connectionRetryTimeout: 1000,
        desiredCapabilities: {
            browserName: 'chrome',
            chromeOptions: {
                prefs: {
                    'download.default_directory': '/data/downloads',
                    'profile.default_content_setting_values.notifications': 2,
                    'exited_cleanly': true,
                    'exit_type': 'None'
                },
                args: [
                    // TODO: https://superuser.com/questions/461035/disable-google-chrome-session-restore-functionality
                    'user-data-dir=/tmp/profile-36',
                    // 'start-fullscreen',
                    'no-sandbox',
                    'disable-session-crashed-bubble',
                    'disable-infobars',
                    'new-window',
                    'disable-geolocation',
                    'disable-notifications',
                    'show-saved-copy',
                    'silent-debugger-extension-api'
                    //'kiosk'
                ]
            }
        },
    };
    
    client = require('webdriverio').remote(webdriverServer);
    client.on('error', e => console.log(e.message));
    client.on('end', () => console.log('Daemon: Closing browser'));
    const connectSession = importer.import('connect webdriver session', {client});
    return connectSession();
};
module.exports = createWebdriverClient;
