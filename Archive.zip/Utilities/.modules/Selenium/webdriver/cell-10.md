verify session?

