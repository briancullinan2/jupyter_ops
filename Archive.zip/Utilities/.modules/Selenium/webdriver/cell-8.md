Manage webdriver sessions?

