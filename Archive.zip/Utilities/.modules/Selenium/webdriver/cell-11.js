var importer = require('../Core');
var {
    updateOrAddSession,
    lockPromise
} = importer.import('update session');

var scanning = false;
var TIMEOUT = 10000;

function verifySession(session) {
    client.requestHandler.sessionID = session[1];
    return client
        .then(() => scanning = true)
        .windowHandle()
        .then(r => client.window(r.value))
        .session()
        .then(s => s.sessionId)
        .catch(e => {
            if(e.message === 'ESOCKETTIMEDOUT' || e.message.indexOf('no such session')) {
                 session[1] = '';
            } else {
                console.log('error ' + session[1]);
                console.log(e)
            }
            // if the session is really old and has an error delete it from the list
            //const index = sessions.map(s => s[1]).indexOf(session[1]);
            //sessions[index][1] = null;
        })
        .then(r => {
            scanning = false;
            return r;
        })
}
module.exports = {
    lockPromise, verifySession
};

var sessions = [];
if(typeof client.verifySession === 'undefined') {
    client.addCommand('verifySession', verifySession);
    client.on('result', (result) => {
        if(scanning) {
            return;
        }
        const currentSession = client.requestHandler.sessionID;
        const updateSession = sessions.filter(s => s[1] === currentSession)[0];
        if(typeof updateSession !== 'undefined') {
            if((new Date()).getTime() - updateSession[0] <= TIMEOUT / 2) {
                return;
            }
        }

        return lockPromise(true)
            .then(() => sessions = updateOrAddSession(currentSession))
            .then(() => lockPromise(false))
            .catch(e => console.log(e));
    });
}
