update session?
