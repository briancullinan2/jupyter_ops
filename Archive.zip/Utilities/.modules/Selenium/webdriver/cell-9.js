var importer = require('../Core');
var readSessions = importer.import('load webdriver sessions', {client});
var {
    verifySession,
    lockPromise
} = importer.import('verify session', {client});

var TIMEOUT = 10000;

function getSessions(inactive = false) {
    const sessions = readSessions();
    const original = client.requestHandler.sessionID;
    var active = [].concat(sessions)
        .filter(session => typeof session[1] !== 'undefined'
                && session[1] !== null && session.length > 0);
    if(inactive) {
        active = active.filter(session => (new Date()).getTime() - session[0] > TIMEOUT);
    }
    var cancelled = false;
    return importer.runAllPromises(active.map(session => (resolve) => {
        if(cancelled) {
            return resolve();
        }
        return verifySession(session)
            .catch(e => console.log(e))
            .then(r => {
                // only try to find 1 decent session
                if(inactive && typeof r !== 'undefined') {
                    cancelled = true;
                }
                return resolve(r);
            })
    }))
        .then(available => {
            client.requestHandler.sessionID = original;
            return available
                .filter(sess => typeof sess !== 'undefined' && sess !== null)
                .filter((elem, pos, arr) => arr.indexOf(elem) === pos)
        })
}

if(typeof client.getSessions === 'undefined') {
    client.addCommand('getSessions', getSessions);
}

module.exports = {
    getSessions,
    lockPromise
};

