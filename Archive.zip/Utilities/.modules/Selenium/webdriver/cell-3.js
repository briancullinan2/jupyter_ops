var importer = require('../Core');
var readSessions = importer.import('load webdriver sessions');
var {
    getSessions,
    lockPromise
} = importer.import('manage webdriver sessions', {client});

var TIMEOUT = 10000;

function connectSession() {
    return client
        .then(() => lockPromise(true, true))
        .getSessions(true)
        // save current session
        .then(validSessions => {
            var sessions = readSessions();
            // the next null or end will be the next available profile id
            var index = sessions.map(s => s[1]).indexOf(validSessions[0] || 0);
            if(index === -1) {
                index = sessions.length;
            }
            client.options.connectionRetryTimeout = TIMEOUT;
            client.options.desiredCapabilities.chromeOptions.args[0] = 'user-data-dir=/tmp/profile-' + index;
            // TODO: fix this, doesn't work on second init, keeps opening new windows if chrome profile path is alreading open for read/write
            if(typeof validSessions[0] !== 'undefined') {
                console.log('using existing session ' + index + ' - ' + validSessions[0]);
                client.requestHandler.sessionID = validSessions[0];
                return client.session()
            } else {
                console.log('new session ' + index);
                return client.init().session();
            }
        })
        .catch(e => {
            client.requestHandler.sessionID = null;
            console.log(e);
        })
        .then(() => lockPromise(false, true))
}
module.exports = connectSession;
