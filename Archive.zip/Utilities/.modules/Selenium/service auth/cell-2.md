Add encrypted to passwords.json?

