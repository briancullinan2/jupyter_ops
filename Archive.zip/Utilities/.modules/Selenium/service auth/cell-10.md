Automatically fill any type of login form using various algorithms?

Try to log in to every site in stored passwords

