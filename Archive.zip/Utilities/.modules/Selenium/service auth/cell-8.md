How to log in to Google using webdriver?

