var importer = require('../Core');
var r = importer.import([
    'selenium docker',
    'set up selenium server',
    'webdriver client'
]);
var {getSeleniumServer, createWebdriverClient} = r;

function approveSelenium(authUrl) {
    return client
        .url(authUrl)
        .loginGoogle()
        .waitForVisible('#scope0 + button', 3000)
        .moveToObject('#scope0')
        .moveToObject('#submit_approve_access')
        .waitForVisible('#submit_approve_access content', 3000)
        .click('#submit_approve_access content')
        .waitForVisible('#code', 3000)
        .getValue('#code');
};

var client, getCredentials;
function authorizeSelenium(authUrl) {
    console.log('Authorizing: ' + authUrl);
    return getSeleniumServer('act-selenium')
        .then(() => {
            client = createWebdriverClient();
            return importer.import([
                'decrypt password',
                'log in Google',
            ], {client})
        })
        .then(() => approveSelenium(authUrl))
        .catch(e => console.log(e))
};
if (typeof client !== 'undefined'
    && typeof client.authorizeSelenium === 'undefined') {
    client.addCommand('authorizeSelenium', authorizeSelenium);
}
module.exports = authorizeSelenium;
