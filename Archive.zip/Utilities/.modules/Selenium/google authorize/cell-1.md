How to exchange token for oauth client?

