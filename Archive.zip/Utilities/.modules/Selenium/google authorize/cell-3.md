How to use selenium to authorize Google access?

