var importer = require('../Core');
var runSeleniumCell = importer.import('selenium cell');
// Load client secrets from a local file.
var path = require('path');
var fs = require('fs');
var google = require('googleapis');
var googleAuth = require('google-auth-library');

// If modifying these scopes, delete your previously saved credentials
// at ~/.credentials/calendar-nodejs-quickstart.json
var SCOPES = ['https://www.googleapis.com/auth/calendar.readonly'];
var TOKEN_DIR, SECRET_PATH, credentials;
try {
    TOKEN_DIR = path.join(process.env.HOME || process.env.HOMEPATH || process.env.USERPROFILE || '', '.credentials');
} catch (e) {
    console.log(e);
    try {
        fs.mkdirSync(TOKEN_DIR);
    } catch (err) {
        if (err.code != 'EEXIST') {
            console.log(err);
        }
    }
}
try {
    SECRET_PATH = path.join(TOKEN_DIR, 'client_secret.json');
    credentials = JSON.parse(fs.readFileSync(SECRET_PATH));
} catch(e) {
    console.log(e);
}

/**
 * Store token to disk be used in later program executions.
 *
 * @param {Object} token The token to store to disk.
 */
function storeToken(token, tokenPath) {
    fs.writeFileSync(tokenPath, JSON.stringify(token));
    console.log('Token stored to ' + tokenPath);
}

/**
 * Create an OAuth2 client with the given credentials, and then execute the
 * given callback function.
 *
 * @param {Object} credentials The authorization client credentials.
 * @param {function} callback The callback to call with the authorized client.
 */
function authorize(scopes = SCOPES) {
    const tokenPath = path.join(TOKEN_DIR, scopes.join('')
        .replace(/[^a-z]*/ig, '_') + '.json');
    var clientSecret = credentials.installed.client_secret;
    var clientId = credentials.installed.client_id;
    var redirectUrl = credentials.installed.redirect_uris[0];
    var auth = new googleAuth();
    var oauth2Client = new auth.OAuth2(clientId, clientSecret, redirectUrl);

    try {
        // Check if we have previously stored a token.
        var token = fs.readFileSync(tokenPath);
        oauth2Client.credentials = JSON.parse(token);
        return Promise.resolve(oauth2Client);
    } catch (e) {
        if (e.code !== 'ENOENT') {
            throw e;
        } else {
            var authUrl = oauth2Client.generateAuthUrl({
                access_type: 'offline',
                scope: scopes
            });
            return runSeleniumCell('authorize google access')
                .then(authorizeSelenium => authorizeSelenium(authUrl))
                .then(code => new Promise((resolve, reject) => {
                    oauth2Client.getToken(code, (err, token) => {
                        if (err) {
                            return reject(err);
                        } else {
                            return resolve(token);
                        }
                    });
                }))
                .then(token => {
                    oauth2Client.credentials = token;
                    storeToken(token, tokenPath);
                    return oauth2Client;
                })
                .catch(e => console.log(e))
        }
    }
};
module.exports = authorize;
authorize;


