How to authenticate to Google APIs?

