filter command permission?
