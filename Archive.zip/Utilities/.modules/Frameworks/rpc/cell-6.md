rpc result?
