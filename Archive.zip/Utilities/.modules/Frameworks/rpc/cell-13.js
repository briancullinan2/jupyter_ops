var importer = require('../Core');
var getResult = importer.import('rpc result');

function handler(event, context, callback) {
    var body = event;
    if (event.body && event.body !== '') {
        body = JSON.parse(event.body);
    }
    // TODO: add Eloqua Notify service entry point for retrieving temporary data?
    // TODO: parse action and call from notify service or call with posted data?
    // TODO: add an entry point for Zuora subscription callout to update single records in eloqua?
    return Promise.resolve([])
        .then(() => getResult({
            command: body['function'] || req.query['function'],
            result: importer.interpret(body['function'] || req.query['function']),
            body: event.body || event,
            circles: ['Public']
        }))
        .then(r => callback(null, {
            'statusCode': 200,
            'headers': { 'Content-Type': 'application/json' },
            'body': JSON.stringify(r, null, 4)
        }))
        // TODO: object assign error?
        .catch(e => {
            console.log(e);
            callback(e, {
                'statusCode': 500,
                'headers': { 'Content-Type': 'text/plain' },
                'body': 'Error: ' + e.message
            })
        });
}

if(typeof module.exports === 'undefined') {
    module.exports = {};
}
module.exports.handler = handler;
