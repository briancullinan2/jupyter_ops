var path = require('path');
var importer = require('../Core');
var getPermissions = importer.import('rpc permissions');
var getParameterNames = importer.import('function parameters',
                                        // prevent recursion
                                        {getResult}); 

// apply parameters is set to false if the caller wants a validated function returned
function getResult(props, applyParameters = true) {
    // filter permissions
    var result;
    var isEmail = false;
    if(typeof props.subject !== 'undefined') {
        isEmail = true;
    }
    
    if (props.result === null) {
        throw new Error('Command not found, please specify a command '
                         + (isEmail ? 'in the subject line' : '')
                         + ' like "megamind settings" without quotes.');
    }
    
    // compare id with permissions
    const permissions = getPermissions();
    Object.assign(props, {
        allowed: props.circles
            .filter(c => {
                const matching = Object.keys(permissions)
                    .filter(k => permissions[k].indexOf(c) > -1 || permissions[k].indexOf('Public') > -1);
                return matching.filter(k => path.basename(props.result.filename) === k.split('[')[0]
                                       && importer.interpret(k).id === props.result.id).length > 0;
            }).length > 0
    });

    // pass error up
    if(!props.allowed) {
        throw new Error('Would have run "' + props.result.id + '" but you don\'t have permission. Deploy your own server to get access to all RPC functions.');
    }
    
    // TODO: make this nicer, ugly because importer doesn't conform to the same importing
    //   style and therefore functions are missing from the context when loaded separately.
    // This is maybe a sign there is something wrong with this style of dependency injection
    var commandResult = props.result.runInNewContext(
        props.result.id.indexOf('rpc.ipynb') === 0
        ? {getResult}
        : (props.result.id.indexOf('import notebook.ipynb') === 0
           ? importer
           : {}));
    if(typeof commandResult === 'object' && commandResult !== null
        && typeof commandResult[Object.keys(commandResult)[0]] === 'function') {
        commandResult = commandResult[Object.keys(commandResult)[0]];
    }
    if(applyParameters && typeof commandResult === 'function') {
        const parameters = getParameterNames(commandResult);
        const parameterValues = props.body
            ? parameters.slice(1).map((k, i) => {
                const p = props.body[k] || props.body[i];
                if(typeof p === 'undefined' || p === 'undefined') {
                    return;
                }
                return p;
            })
            : [];
        return commandResult.apply(importer, parameterValues);
    } else {
        return commandResult;
    }
}
module.exports = getResult;

