store rpc result?
