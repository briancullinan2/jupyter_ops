aws rpc wrapper?
