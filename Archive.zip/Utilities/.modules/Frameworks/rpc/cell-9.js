var importer = require('../Core');

var COMMENTS = /((\/\/.*$)|(\/\*[\s\S]*?\*\/))/mg;
var DEFAULT_PARAMS = /=[^,]+/mg;
var FAT_ARROWS = /=>[\s\S]*$|{[\s\S]*$/mg;

function getParameterNames(search) {
    var result;
    if(typeof search === 'function') {
        result = search;
    } else {
        if(typeof getResult === 'undefined') {
            var getResult = importer.import('rpc result');
        }
        result = getResult({
            command: search,
            result: importer.interpret(search),
            circles: ['Function']
        }, false);
    }

    var fnName = result.name;
    
    var code = result.toString()
        .replace(COMMENTS, '')
        .replace(FAT_ARROWS, '')
        .replace(DEFAULT_PARAMS, '');

    var result = code.slice(code.indexOf('(') + 1, code.indexOf(')'))
        .match(/([^\s,]+)/g);

    return result === null
        ? [fnName]
        : [fnName, ...result];
}

module.exports = getParameterNames;
