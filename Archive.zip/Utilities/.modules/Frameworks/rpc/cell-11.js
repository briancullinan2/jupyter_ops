var cors = require('cors')({origin: true});
var importer = require('../Core');
var getResult = importer.import('rpc result');
var functions = require('firebase-functions'),
    admin = require('firebase-admin');

try {
    admin.initializeApp(functions.config().firebase);
} catch (e) {
    console.log(e);
}

if(typeof module.exports === 'undefined') {
    module.exports = {};
}

module.exports.rpc = functions.https.onRequest((req, res) => {
    cors(req, res, () => {
        return Promise.resolve([])
            .then(() => getResult({
                command: req.body['function'] || req.query['function'],
                result: importer.interpret(req.body['function'] || req.query['function']),
                body: req.method === 'POST' ? req.body : req.query,
                circles: ['Public']
            }))
            .then(r => res.send(JSON.stringify(r, null, 4)))
            // TODO: object assign error?
            .catch(e => { console.log(e); res.send(e + '') });
    });
})
