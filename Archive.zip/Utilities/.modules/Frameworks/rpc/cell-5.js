var importer = require('../Core');
var updateEvent = importer.import('update create merge event');
var ISODateString = importer.import('convert date iso');
var getOauthClient = importer.import('import google calendar api');
var getParameterNames = importer.import('function parameters');
var getResult = importer.import('rpc result');

var options = {
    calendarId: 'Commands'
};

function updateResultEvent(response, friend, isError, isStarting = false) {
    const config = {
        start: {
            dateTime: ISODateString(new Date(friend.date.getTime()))
        },
        end: {
            dateTime: ISODateString(new Date(friend.date.getTime() + 60 * 30 * 1000))
        },
        summary: 'Result: ' + friend.id,
        description: JSON.stringify(response, null, 4),
        colorId: isStarting ? 9 : (isError ? 11 : 10)
    }
    return updateEvent(config, options).then(() => response);
}

function storeResult(friend) {
    if(typeof friend === 'undefined' || friend === null
       || friend.already !== false) {
        // skip commands that have already been run
        throw new Error('Nothing to do!');
    }
    
    var isError;
    return getOauthClient(options)
        // create a new events to store the results
        // process the command, this should return a function to be called after event
        .then(() => updateResultEvent('starting ' + friend.result.filename, friend, false, true))
        .then(() => getResult(friend))
        .catch(e => {
            console.log(e);
            isError = true;
            return Object.getOwnPropertyNames(e).reduce((alt, key) => {
                alt[key] = e[key];
                return alt;
            }, {})
        })
        // store as an event for tracking
        .then(response => updateResultEvent(response, friend, isError))
        .catch(e => console.log(e))
}
module.exports = storeResult;

