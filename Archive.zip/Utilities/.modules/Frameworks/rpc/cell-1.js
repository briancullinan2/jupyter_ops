var _ = require('lodash');
var importer = require('../Core');
var FUNCTION_GROUPS = ['Function', 'Public'];
var SELENIUM_GROUPS = ['Selenium'];
var UNITTEST_GROUPS = ['Unit Test']; // TODO: identified using describe
var DEFAULT_GROUPS = []
var PUBLIC = {
    'google contacts.ipynb[google contact settings]': ['Function', 'Inner Circle', 'Public'],
    'import notebook.ipynb[search notebook questions]' : ['Function', 'Public'],
    'rpc.ipynb[permissions]' : ['Function', 'Public'],
    'rpc.ipynb[parameter names]' : ['Function', 'Public'],
    'gulp.ipynb[search notebooks]' : ['Function', 'Public'],
    'data collection.ipynb[meta search all]' : ['Function', 'Public'],
    'data collection.ipynb[schedule search all]' : ['Function', 'Public'],
    'data collection.ipynb[tell joke]' : ['Function', 'Public'],
};

var REGEX_EXPORTS = /exports[^=]*?\s*=\s*([^ ]*)\s*;/igm;
var REGEX_NAMED = /function\s+([^\( ]*)\s*\(/igm

function regexToArray(ex, str, i = 0) {
    var co = []; var m;
    while ((m = ex.exec(str)) && co.push(m[i])) ;
    return co;
};

function getExports(code) {
    const named = regexToArray(REGEX_NAMED, code, 1);
    const namedExports = regexToArray(REGEX_EXPORTS, code, 1);
    return _.intersection(named, namedExports);
}

var defined = importer.interpret(Object.keys(PUBLIC))
    .map(r => r.id);
var empty = importer.interpret().filter(r => defined.indexOf(r.id) === -1);
// TODO: move these classifications to import notebook?
var AVAILABLE = empty.reduce((acc, r) => {
    const id = r.id.replace(/\[.*]/ig, '') + '[' + r.question + ']';
    // TODO: find the shortest words from the query to match the sam cell
    // TODO: filter RPC functions by module.exports = <name> and function <name> matching function name?
    try {
        const search = importer.interpret(id);
        if(search.id !== r.id) {
            console.error('Not going to work ' + id);
        } 
        if(search.filename.indexOf('Selenium') > -1) {
            if(getExports(search.code).length > 0) {
                acc[id] = SELENIUM_GROUPS.concat(FUNCTION_GROUPS);
            } else {
                acc[id] = SELENIUM_GROUPS;
            }
            // TODO: called using selenium runner?
        } else if(getExports(search.code).length > 0) {
            acc[id] = FUNCTION_GROUPS;
        } else {
            acc[id] = [];
        }
    } catch (e) { // ignore
    }
    return acc;
}, {});

// TODO: filter RPC functions by fully unit tested?
// TODO: filter by local system groups?

function getPermissions() {
    // Always return the permission set so it can't be manipulated by another command.
    return Object.assign({}, PUBLIC, AVAILABLE);
}

if(typeof $$ !== 'undefined') {
    console.log(getPermissions());
}
module.exports = getPermissions;
