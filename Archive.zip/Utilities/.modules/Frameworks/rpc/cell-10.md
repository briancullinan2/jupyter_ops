firebase rpc wrapper?
