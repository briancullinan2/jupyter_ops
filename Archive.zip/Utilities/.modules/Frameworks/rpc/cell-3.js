var importer = require('../Core');
var getPermissions = importer.import('rpc permissions');
var getDaysEvents = importer.import('days events');
var getSettings = importer.import('google contact settings');
var getOauthClient = importer.import('import google calendar api');

var options = {
    calendarId: 'Commands'
};

// TODO: move this logic out to a higher level coordinator?
function filterCommand(command, date, id, user) {
    const props = {};
    return getOauthClient(options)
        .then(() => getSettings(user))
        .then(settings => {
            // assign user controls and interpreted command
            Object.assign(props, settings);
            try {
                console.log(settings.circles)
                Object.assign(props, {
                    result: importer.interpret(command)
                });
                // if looking for settings use the user name provided to this function for lookup
                // TODO: accept parameters from message context
                if(props.result.id === importer.interpret('google contacts.ipynb[google contact settings]').id) {
                    props.result.runInNewContext = () => settings;
                }
            } catch (e) {
                if((e + '').indexOf('Nothing found') > -1) {
                    Object.assign(props, {result: null});
                } else {
                    throw e;
                }
            }
        })
        .then(() => getDaysEvents(new Date(date), options))
        .then(events => {
            // filter already sent
            const already = events
              .filter(e => e.event.summary.indexOf('Result:') > -1 && e.event.summary.indexOf(id) > -1).length > 0;
            Object.assign(props, {already: already})
        })
        .catch(e => console.log(e))
        .then(() => props)
}
module.exports = filterCommand;
