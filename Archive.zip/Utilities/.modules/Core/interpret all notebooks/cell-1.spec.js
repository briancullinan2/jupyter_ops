var path = require('path');
var glob = require('glob');
var fs = require('fs');
var assert = require('assert');
var importer = require('../Core');
var {
    fuseSearch,
    interpretMarkdown,
    cacheCells
} = importer.import('interpret questions.ipynb');

// How to walk directories and files recursively and synchronously
var listInProject;
function cacheAll(dirname) {
    if(typeof listInProject === 'undefined') {
        listInProject = importer.import('list project files');
        /*
        const cell = fuseSearch('list project files');
        assert(!!cell)
        listInProject = importer.runInNewContext(cell.code, {
            __filename: cell.filename
        }, {}, false);
        */
    }
    return listInProject(dirname, '**/*.ipynb')
        .map(n => cacheCells(importer.getCells(n, ['*', 'markdown', 'code']), n))
};

// TODO: move this below
// just do it in load mode
if(typeof describe === 'undefined') {
    var it = ((l, func) => func());
    var beforeEach = ((func) => func());
    var describe = ((l, func) => func());
}

describe('notebook search loader', () => {
    it('should load file-system', () => {
        const filesystemPath = path.join(__dirname, '../Utilities/file system.ipynb');
        assert(fs.existsSync(filesystemPath), 'missing ' + path.resolve(filesystemPath));
        cacheCells(importer.getCells(filesystemPath, ['*', 'markdown', 'code']), filesystemPath);
    })
    
    it('should load interpreter', () => {
        const interpreterPath = path.join(__dirname, '../Core/interpret all notebooks.ipynb');
        assert(fs.existsSync(interpreterPath), 'missing ' + path.resolve(interpreterPath));
        cacheCells(importer.getCells(interpreterPath, ['*', 'markdown', 'code']), interpreterPath);
    })
    /*
    it('should refresh cache when file changes', () => {
        assert(fs.existsSync(path.join(__dirname, '../Core/import notebook.ipynb')),
               'Can\'t find Core notebooks ' + path.resolve(path.join(__dirname, '../Core')));
        cacheAll(path.join(__dirname, '../'));
        assert(true);
    })
    */
});

module.exports = {
    fuseSearch,
    interpretMarkdown,
    cacheAll,
    cacheCells
};

