find all notebooks?

How to get markdown from all notebooks in {directory}?

How to interpret a jupyter {directory}?

