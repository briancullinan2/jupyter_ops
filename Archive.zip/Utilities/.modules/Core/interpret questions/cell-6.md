How to answer questions using jupyter notebooks and simple search?

How to turn jupyter notebooks in to modules?

How to search jupter notebooks for questions and answers?

