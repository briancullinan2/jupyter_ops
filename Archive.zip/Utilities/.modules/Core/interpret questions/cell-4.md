How to display interpreted results in markdown?

