How to find questions leading up to jupter cells?

How to read markdown leading up to code cells?
