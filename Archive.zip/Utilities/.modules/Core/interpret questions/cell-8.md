How to test the interpreter works
