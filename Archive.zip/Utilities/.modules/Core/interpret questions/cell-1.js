// TODO: use the m flag option for regexp?

function accumulateMarkdown(cells) {
    var counter = 0, prev = [];
    return cells.reduce((md, c) => {
        counter++;
        var source = c.source.join('');
        if (c.cell_type === 'markdown') {
            prev.push(source);
            return md;
        } else if (c.cell_type !== 'code') {
            return md;
        }
        // TODO: improve the counter
        var cell = {
            code: source, markdown: prev,
            from: counter - 1, to: counter,
            language: c.language
        };
        prev = [];
        md.push(cell);
        return md;
    }, []);
}

module.exports = accumulateMarkdown;

