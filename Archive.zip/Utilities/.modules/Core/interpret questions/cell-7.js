// install fuse
var path = require('path');
var Fuse = require('fuse.js');
var importer = require('../Core');

var FUSE_CONFIG = {
    caseSensitive: false,
    findAllMatches: true,
    distance: 100,
    threshold: 0.5,
    tokenize: false,
    shouldSort: true,
    keys: ['question'],
    id: 'id'
}
var fuse = new Fuse(cacheCells([], ''), FUSE_CONFIG);

// filter query results by filename
function filterFilename(arr, fname) { return arr.filter(id => id.substr(0, fname.length + 1) === fname + '['); }

function fuseSearch(message) {
    const cellIds = cacheCells([], '').map(c => c.id);
    const query = path.basename(message).split(/[\[\]]/ig);
    const files = filterFilename(cellIds, query[0]);
    const isFileSearch = query.length === 1 && files.length > 0;
    let searchResults;
    if (query.length === 3) {
        // filter query using exact cell if it is numeric
        searchResults = filterFilename(parseInt(query[1]) + '' === query[1] // check if using numeric
            ? cellIds.filter(id => id === path.basename(message))
            : fuse.search(query[1]), query[0])
    } else if (isFileSearch) {
        searchResults = files;
    } else {
        searchResults = fuse.search(message);
    }
    return isFileSearch ? interpretObject(searchResults) : interpretObject([searchResults[0]])[0];
}

function getFresher(cache) {
    try {
        const r = importer.getCells(cache.filename, ['*', 'markdown', 'code'])
        const cells = r.slice(cache.from, cache.to);
        cache.fresher = accumulateMarkdown(cells)[0].code;
    } finally {
        return cache;
    }
}

function interpretObject(results) {
    return typeof results[0] !== 'undefined' && typeof results[0] !== 'string'
        ? results.map((res) => res.map(r => {
            return getFresher(cacheCells(r));
        }))
        : results.map(r => {
            return getFresher(cacheCells(r));
        });
}

module.exports = fuseSearch;
