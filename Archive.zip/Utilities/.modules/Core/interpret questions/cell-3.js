// TODO: interpret markdown leading up to code results and find the resulting function in the list
// for now, the boring solution is to assume all markdown output is a question?
var path = require('path');
var MATCH_QUESTIONS = (/^.*\?.*$/igm);
//var re2 = new RegExp('(^|\\n)//.*\\?([\\n\\s]+|$)', 'ig')

// How to store code markdown results for later use?
if (typeof cellCache === 'undefined') {
    var cellCache = [];
}
if (typeof cacheIds === 'undefined') {
    var cacheIds = {};
}

// How to convert a string to an Array of RegEx matches
function regexToArray(ex, str, i = 0) {
    var co = [];
    var m;
    while ((m = ex.exec(str)) && co.push(m[i])) ;
    return co;
};

function cacheCells(cells, notebook) {
    if(typeof cells === 'string' && cacheIds[cells] && typeof notebook === 'undefined') {
        return cacheIds[cells];
    }
    if(cells.length === 0 || notebook.length === 0) {
        return cellCache;
    }
    var filename = path.basename(notebook);
    // update cells when files change
    cellCache.forEach(c => {
        if(c.id.split('[')[0] === filename) {
            // does this evaluate in contant time because it is by reference?
            cellCache.splice(cellCache.indexOf(c), 1);
        }
    });
    var newCache = accumulateMarkdown(cells);
    newCache.forEach((c, i) => {
        var questions = regexToArray(MATCH_QUESTIONS, c.markdown)
            .map(r => r.replace(/how to|\?/ig, '').trim())
            .concat(regexToArray(MATCH_QUESTIONS, c.source)
                .map(r => r.replace(/how to|\?/ig, '').trim()));
        cacheIds[filename + '[' + i + ']'] = Object.assign({}, c, {
            id: filename + '[' + i + ']',
            filename: notebook,
            questions: questions,
            notebook: filename,
        });
        questions.forEach((q) => cellCache.push({
            id: filename + '[' + i + ']',
            question: q
        }));
    });
    return cellCache;
}
module.exports = cacheCells;
