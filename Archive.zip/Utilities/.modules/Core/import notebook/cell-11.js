var path = require('path');
var vm = require('vm');

// initialize
function requireCode(code, pathToCode, tmpGlobal) {
    var Module = require('module').Module;
    var path = require('path');

    // must have a new name for every generation otherwise cache will be returned
    var filepath = path.resolve(process.cwd(), pathToCode);
    var dirname = path.dirname(filepath);

    //var cachedModule = Module._cache[filepath];
    //if (cachedModule && tmpGlobal.useCache !== false) {
    //    tmpGlobal.module = cachedModule;
    //    return cachedModule.exports;
    //}

    var mod = new Module(filepath, tmpGlobal.module);
    tmpGlobal.module = mod;
    Module._cache[filepath] = mod;

    mod.filename = filepath;
    mod.paths = Module._nodeModulePaths(dirname);
    
    const validVars = Object.keys(tmpGlobal)
        .filter(k => k.match(/^[a-z_][a-z0-9_]*$/i))
        .join(',');
    mod._compile(`module.exports = (({${validVars}}) => {
${code}
return exports || module.exports;
})`, filepath);
    const result = mod.exports(tmpGlobal);
    mod.loaded = true;
    tmpGlobal.exports = mod.exports;
    return mod.exports;
}

function runInNewContext(code, ctx, options, isModule = true) {
    const oldDir = process.cwd();
    const tmpGlobal = ctx || {};
    Object.assign(tmpGlobal, ctx);
    Object.assign(options || {}, { lineOffset: -1 });
    if(!options.filename) {
        options.filename = ctx.__filename;
    }
    const result = requireCode(code, options.filename, tmpGlobal);
    return tmpGlobal.module.exports || result;
}

if(typeof module.exports === 'undefined') {
    module.exports = {};
}
module.exports.runInNewContext = runInNewContext;

// $$.done() for our dumb parser

