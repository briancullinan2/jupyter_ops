
// initialize
var path = require('path');

var fuseSearch;
var cacheCells;
function interpret(query) {
    if(typeof fuseSearch === 'undefined') {
        var interpreter = importNotebook('interpret all notebooks.ipynb')[0];
        fuseSearch = interpreter.fuseSearch;
        cacheCells = interpreter.cacheCells;
        interpreter.cacheAll(path.join(__dirname, '../'));
    }
    if(typeof query === 'undefined' || query === null || query === false) {
        return cacheCells([], '');
    }
    const searches = (typeof query === 'string'
                      ? [query]
                      : query).map(q => fuseSearch(q));
    if (searches.length === 0
        || (typeof query === 'string'
            && typeof searches[0] === 'undefined')
        || (searches.length === 1
            && searches[0].length === 0)) {
        throw new Error('Nothing found for ' + JSON.stringify(query).substr(0, 200));
    }
    const fileMode = typeof query === 'string' && query.indexOf('.ipynb') > -1 && query.indexOf('[') === -1;
    const results = (fileMode ? searches[0] : searches).map(r => {
        if (typeof r === 'undefined') {
            return r;
        }
        // must have a unique id for each unique cell so that
        // individual cells can serve as modules as well as notebooks
        // adding the cell id as a part of the filename
        r.runInNewContext = (ctx) => {
            return runInNewContext(
                r.fresher,
                Object.assign(ctx || {}, {
                    useCache: false,
                    __filename: r.filename
                }),
                {filename: path.join(path.dirname(path.resolve(r.filename)), r.id)}, false);
        };
        return r;
    });
    return typeof query === 'string' && !fileMode
        ? results[0]
        : results;
}

if(typeof module.exports === 'undefined') {
    module.exports = {};
}
module.exports.interpret = interpret;

// $$.done() for our dumb parser

