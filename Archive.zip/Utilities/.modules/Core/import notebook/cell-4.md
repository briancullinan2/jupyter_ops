
How to parse cells of {types} from a notebook?

