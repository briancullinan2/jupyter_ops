// initialize
var path = require('path');
var fs = require('fs');

// provide a function for importing any notebook as a module and executing it
function getCellsOrDirectory(filename) {
    const fname = filename.replace('.ipynb', '');
    if (fs.existsSync(fname)
        && fs.statSync(fname).isDirectory()) {
        const files = fs.readdirSync(fname)
            .sort((a, b) => parseInt(a.replace(/[^0-9]/ig, '')) - parseInt(b.replace(/[^0-9]/ig, ''))) //sort numerically
            .filter(f => f.indexOf('.js') > -1);
        return files.map(f => fs.readFileSync(path.join(fname, f)).toString());
    }
    else {
        return getCells(filename, ['javascript', 'code'])
            .map((c, i) => ({
                fresher: c.source.join(''),
                id: path.basename(filename) + '[' + i + ']',
                filename: filename,
                runInNewContext: (ctx) => {
                    return runInNewContext(c.source.join(''), Object.assign(ctx || {}, {
                        useCache: false,
                        __dirname: path.dirname(filename),
                        __filename: filename,
                    }), {filename: path.join(path.dirname(filename), path.basename(filename) + '[' + i + ']')}, false);
                }
            }));
    }
}

// output nothing here, cached version of this function is assigned below.
if (typeof imported !== 'object' || imported === null) {
    var imported = {};
}

// How to test if a notebook has already been imported?
function importNotebook(notebook, ctx = {}) {
    if (typeof notebook === 'undefined') {
        return Promise.resolve({});
    }
    var cells;
    // TODO: do Core notebooks synchronously?
    if(typeof notebook === 'string' && fs.existsSync(path.resolve(__dirname, notebook))) {
        // ONLY RETURN CACHE?
        if (typeof imported[notebook] !== 'undefined'
            && path.basename(notebook) === 'interpret questions.ipynb') {
            return imported[notebook];
        }
        cells = getCellsOrDirectory(path.resolve(path.resolve(__dirname, notebook)));
    } else {
        cells = interpret(notebook);
        if( typeof cells.fresher !== 'undefined') {
            imported[notebook] = cells.runInNewContext(ctx);
            return imported[notebook];
        }
    }
    
    imported[notebook] = cells.reduce((obj, c, i) => {
        var result = c.runInNewContext(Object.assign(ctx, obj));
        if(typeof result === 'object' && result !== null
           && typeof result[Object.keys(result)[0]] === 'function') {
            const func = result[Object.keys(result)[0]];
            obj[cells[i].id] = func;
            obj[func.name] = obj[cells[i].id];
        }
        if (typeof result === 'function') {
            obj[cells[i].id] = result;
            obj[result.name] = obj[cells[i].id];
        }
        obj[i] = result;
        Object.assign(ctx, obj);
        return obj;
    }, {});
    return imported[notebook];
}
if(typeof module.exports === 'undefined') {
    module.exports = {};
}
module.exports.import = importNotebook;

// $$.done(); for our dumb parser

