How to stream json using a {match} function?
