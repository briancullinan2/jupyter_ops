How to run all promises sequentially?

