// initialize

function runAllPromises(promises) {
    return promises.reduce((promise, func) => {
        return promise.then(result => {
            return (typeof func == 'function'
                ? (new Promise(func)) : Promise.resolve(func))
                .then(Array.prototype.concat.bind(result));
        });
    }, Promise.resolve([]));
};
if(typeof module.exports === 'undefined') {
    module.exports = {};
}
module.exports.runAllPromises = runAllPromises;

// $$.done() for our dumb parser

