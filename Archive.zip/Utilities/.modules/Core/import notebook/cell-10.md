Import arbitrary code in to the current context?

Import arbitrary code in to a new context?

How does node module require work?

