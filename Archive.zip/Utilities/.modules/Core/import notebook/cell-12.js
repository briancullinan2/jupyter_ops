// initialize

if (typeof imported !== 'object' || imported === null) {
    var imported = {};
}

imported['import notebook.ipynb'] = module.exports;

// $$.done() for our dumb parser

