// initialize

var fs = require('fs');
var jp = require('jsonpath-plus');
var fileCache = {};

function streamJson(file, path, match = ((c) => true)) {
    const json = JSON.parse(fs.readFileSync(file).toString());
    const nodes = jp({json: Object.assign({}, json), path: '$..*', resultType: 'all', callback: n => {
        if(typeof n.value !== 'object' || n.value === null) {
            return;
        }
        return match({
            path: n.path.split(/[\\'\]\[\$]+/igm).slice(1),
            value: n.value
        });
    }});
//    return nodes
//        .filter(n => )
//        .forEach(n => );
}
if(typeof module.exports === 'undefined') {
    module.exports = {};
}
module.exports.streamJson = streamJson;


// $$.done() for our dumb parser
